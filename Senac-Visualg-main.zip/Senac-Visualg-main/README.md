# Senac Visualg
Exercícios feitos para praticar o raciocínio lógico.
